from typing import List
from pyspark.sql import DataFrame, Window
from pyspark.sql.functions import col, concat, row_number

class transformations:

    def dedup(self, df: DataFrame, dedup_cols: List[str], cdc: str):
        # Create a deduplication key
        df = df.withColumn("dedupKey", concat(*[col(c) for c in dedup_cols]))

        # Define window: partition by dedupKey, order by CDC timestamp (descending)
        window_spec = Window.partitionBy("dedupKey").orderBy(col(cdc).desc())

        # Assign row numbers within each partition
        df = df.withColumn("dedupCounts", row_number().over(window_spec))

        # Keep only the first row per dedupKey (latest record)
        df = df.filter(col("dedupCounts") == 1)

        # Drop helper columns
        df = df.drop("dedupCounts", "dedupKey")
        return df
    

    def process_timestamp(self,df):
        df = df.withColumn("process_timestamp",current_timestamp())
        return df
    
    def upsert(self,df,key_cols,table,cdc):
        merge_condition = " AND ".join([f"src{i} = trg.{i}" for i in key_cols])
        dlt_obj = DeltaTable.forName(spark,f"pysparkdbt.silver.{table}")
        dlt_obj.alias("trg").merge(df.alias("src"),merge_condition)\
                            .whenMatchedUpdateAll(condition = f"src.{cdc} >= trg.{cdc}")\
                            .whenNotMatchedInsertAll()\
                            .execute()
        return 1